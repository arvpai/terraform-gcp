from google.cloud import bigquery
import base64, json, sys, os, datetime

def pubsub_to_bigq(event, context):
   pubsub_message = base64.b64decode(event['data']).decode('utf-8')
   print("Raw message: "+event['data'])

   data = json.loads(pubsub_message)
   print("JSON message")
   print(data)

   stringToDate = datetime.datetime.strptime(data['dateSold'], "%Y-%m-%d").date()

   data['dateSold'] = stringToDate

   to_bigquery(os.environ.get('dataset'), os.environ.get('table'), data)


def to_bigquery(dataset, table, document):

   try:
      bigquery_client = bigquery.Client()
      dataset_ref = bigquery_client.dataset(dataset)
      table_ref = dataset_ref.table(table)
      table = bigquery_client.get_table(table_ref)
      print(document)
      errors = bigquery_client.insert_rows(table, [document])

      if errors != [] :
         print(errors, file=sys.stderr)

   except:
      print("Error in processing JSON")
   finally:
      print("Processing Complete")
