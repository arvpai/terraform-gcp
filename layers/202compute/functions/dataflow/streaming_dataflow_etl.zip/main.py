import os
import json
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.options import pipeline_options
from apache_beam.io.gcp.pubsub import ReadFromPubSub
from apache_beam.io.gcp.bigquery import BigQueryDisposition, WriteToBigQuery
from apache_beam.io import WriteToText
from apache_beam.runners import DataflowRunner
from google.cloud import pubsub_v1

def trigger_streaming_pipeline(event, context):
    table = os.environ.get('project_id')+':'+os.environ.get('bigquery_dataset')+'.'+os.environ.get('bigquery_table')
    schema = "propertyId:integer,customerId:integer,address:string,town:string,county:string,postCode:string,propertyAge:integer,propertyType:string,totalRooms:integer,totalBedrooms:integer,propertyArea:integer,priceSold:integer,dateSold:date"

    job_name = os.environ.get('project_id')+ '-' +os.environ.get('project_region')+ '-' + os.environ.get('process_name')
    bucket = 'gs://'+os.environ.get('bucket_name')+'/'+job_name

    options = PipelineOptions(
        streaming=True,
        project=os.environ.get('project_id'),
        region=os.environ.get('project_region'),
        job_name= job_name,
        staging_location="%s/staging" % bucket,
        temp_location="%s/temp" % bucket
    )

    # step-1 : create pipeline as DataflowRunner and pass all set options(from above)
    pipeline = beam.Pipeline(DataflowRunner(), options=options)
    # step-2 : read pubsub topic as JSON msg
    pubsub = (pipeline | "Read Topic" >> ReadFromPubSub(topic=os.environ.get('topic_id'))
              | "To Dict" >> beam.Map(json.loads))

    # step-3 : write msg data to bigquery table.
    pubsub | "Write To BigQuery" >> WriteToBigQuery(table=table, schema=schema,
                                                    create_disposition=BigQueryDisposition.CREATE_IF_NEEDED,
                                                    write_disposition=BigQueryDisposition.WRITE_APPEND)
    # step-4 : start pipeline
    pipeline.run()
