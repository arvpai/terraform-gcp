import logging
import os

from google.cloud import bigquery
from src import expectations


def load_config():
    """Load environment variables config"""
    DATASET = os.environ.get("DATASET")
    BUCKET = os.environ.get("BUCKET")
    TABLE = os.environ.get("TABLE")
    VALIDATE = True

    assert DATASET, "Dataset environment variable not set"
    assert BUCKET, "GCS bucket environment variable not set"
    assert TABLE, "Bigquery table name environment variable not set"

    return DATASET, BUCKET, TABLE, VALIDATE


def batch_load_csv_to_bq(data, context):
    """Batch load csv file from GCS to Bigquery"""

    DATASET, BUCKET, TABLE, VALIDATE = load_config()

    data_uri = f"gs://{BUCKET}/{data['name']}"

    # run great expectations validations suite
    if VALIDATE:
        logging.info("Running data validation")
        expectations.run_validation(data_uri)

    client = bigquery.Client()
    dataset_ref = client.dataset(DATASET)
    job_config = bigquery.LoadJobConfig()
    job_config.source_format = bigquery.SourceFormat.CSV

    load_job = client.load_table_from_uri(
        data_uri, dataset_ref.table(TABLE), job_config=job_config
    )
    load_job.result()
    logging.info("Job finished")

    destination_table = client.get_table(dataset_ref.table(TABLE))
    logging.info("Loaded {} rows.".format(destination_table.num_rows))
