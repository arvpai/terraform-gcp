"""Expectations Checkpoint"""
import logging
import os

from great_expectations.checkpoint import SimpleCheckpoint
from great_expectations.core.batch import RuntimeBatchRequest
from great_expectations.data_context import BaseDataContext
from great_expectations.data_context.types.base import DataContextConfig

PROJECT = os.environ.get("PROJECT", "")
BUCKET = os.environ.get("BUCKET", "")
VALIDATION_BUCKET = os.environ.get("VALIDATION_BUCKET", "")
TABLE = os.environ.get("TABLE", "")
BATCH_SPEC_PASSTHROUGH = {
    "reader_options": {
        "header": None,
        "names": [str(i) for i in range(13)],
        "index_col": False,
    }
}
PROJECT_CONFIG = DataContextConfig(
    config_version=2,
    plugins_directory=None,
    config_variables_file_path=None,
    datasources={
        "my_gcs_datasource": {
            "class_name": "Datasource",
            "module_name": "great_expectations.datasource",
            "execution_engine": {"class_name": "PandasExecutionEngine"},
            "data_connectors": {
                "default_runtime_data_connector_name": {
                    "class_name": "RuntimeDataConnector",
                    "batch_identifiers": ["default_identifier_name"],
                },
                "default_inferred_data_connector_name": {
                    "class_name": "InferredAssetGCSDataConnector",
                    "bucket_or_name": BUCKET,
                    "prefix": TABLE,
                    "default_regex": {
                        "pattern": "(.*)\\.csv",
                        "group_names": ["data_asset_name"],
                    },
                },
            },
        }
    },
    stores={
        "expectations_GCS_store": {
            "class_name": "ExpectationsStore",
            "store_backend": {
                "class_name": "TupleGCSStoreBackend",
                "project": PROJECT,
                "bucket": VALIDATION_BUCKET,
                "prefix": "data_docs/expectations",
            },
        },
        "validations_GCS_store": {
            "class_name": "ValidationsStore",
            "store_backend": {
                "class_name": "TupleGCSStoreBackend",
                "project": PROJECT,
                "bucket": VALIDATION_BUCKET,
                "prefix": "data_docs/validations",
            },
        },
        "evaluation_parameter_store": {"class_name": "EvaluationParameterStore"},
    },
    expectations_store_name="expectations_GCS_store",
    validations_store_name="validations_GCS_store",
    evaluation_parameter_store_name="evaluation_parameter_store",
    data_docs_sites={
        "gcs_site": {
            "class_name": "SiteBuilder",
            "store_backend": {
                "class_name": "TupleGCSStoreBackend",
                "project": PROJECT,
                "bucket": VALIDATION_BUCKET,
                "prefix": "data_docs",
            },
            "site_index_builder": {
                "class_name": "DefaultSiteIndexBuilder",
            },
        }
    },
    validation_operators={
        "action_list_operator": {
            "class_name": "ActionListValidationOperator",
            "action_list": [
                {
                    "name": "store_validation_result",
                    "action": {"class_name": "StoreValidationResultAction"},
                },
                {
                    "name": "store_evaluation_params",
                    "action": {"class_name": "StoreEvaluationParametersAction"},
                },
                {
                    "name": "update_data_docs",
                    "action": {"class_name": "UpdateDataDocsAction"},
                },
            ],
        }
    },
    anonymous_usage_statistics={"enabled": False},
)


def build_data_context(config: DataContextConfig) -> BaseDataContext:
    """Define the great expectations data context"""
    return BaseDataContext(config)


def build_batch_request(
    gcs_file_path: str, batch_spec_passthrough: dict
) -> RuntimeBatchRequest:
    """Build the batch request which specifies which file to test

    Args:
        gcs_file_path (str): gcs file path to the data which needs to be tested
        batch_spec_passthrough (dict): dictionary containing file specific information
            for reading the file. E.g. pd.read_csv arguments

    Returns:
        RuntimeBatchRequest

    """

    return RuntimeBatchRequest(
        datasource_name="my_gcs_datasource",
        data_connector_name="default_runtime_data_connector_name",
        data_asset_name=gcs_file_path,  # this can be anything that identifies this data_asset for you
        runtime_parameters={"path": gcs_file_path},  # Add your GCS path here.
        batch_identifiers={"default_identifier_name": "default_identifier"},
        batch_spec_passthrough=batch_spec_passthrough,
    )


def run_validation(gcs_file_path: str) -> None:
    """Run the expecation suite"""
    context = build_data_context(config=PROJECT_CONFIG)
    batch_request = build_batch_request(gcs_file_path, BATCH_SPEC_PASSTHROUGH)

    checkpoint_config = {
        "config_version": 1.0,
        "class_name": "Checkpoint",
        "run_name_template": f"%Y%m%d-%H%M%S-{gcs_file_path.split('/')[-1].split('.')[0]}",
        "validations": [
            {
                "batch_request": batch_request.to_json_dict(),
                "expectation_suite_name": TABLE,
            },
        ],
    }

    checkpoint = SimpleCheckpoint(name=TABLE, data_context=context, **checkpoint_config)
    checkpoint_result = checkpoint.run()

    if checkpoint_result["success"]:
        logging.info("Validation successful")
        logging.info(
            f"Validation results available at gs://{VALIDATION_BUCKET}/data_docs"
        )
    else:
        logging.error(
            f"Validation unsuccessful. See results at gs://{VALIDATION_BUCKET}/data_docs"
        )
        raise Exception
